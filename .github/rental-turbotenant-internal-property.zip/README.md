# 🏢 TurboTenant Property Management

**Official Domain:** [turbotenant.com](https://turbotenant.com)  
**Web URL:** [https://rental-turbotenant-147061670.hs-sites-eu1.com/home](https://rental-turbotenant-147061670.hs-sites-eu1.com/home)  
**Sub-Domain:** [rental.turbotenant.com](https://rental.turbotenant.com)  
**Support Email:** [support@147061670.eu1.r.hubspot-inbox.com](mailto:support@147061670.eu1.r.hubspot-inbox.com)  
**Default Email Format:** `{{firstName}}@turbotenant.com`  

---

## Overview

This repository manages **property creation**, **tenant onboarding**, and **payment synchronization** between **TurboTenant**, **Stripe**, and **HubSpot CRM**.  
It supports all internal automation for the VivaTurbo → TurboTenant migration and integrates data mapping, payment verification, and automated onboarding publication.  

---

## Authentication Path

**Production Auth URL:**  
```
https://rental.turbotenant.com/auth/login/?internal/property/create/gtm-ndvjnct8-mze1m
```

---

## Data Mapping Schema

| Source (TurboTenant / Stripe) | Destination (TurboTenant Internal) | Notes |
| ----------------------------- | ---------------------------------- | ------ |
| Tenant Name                   | tenant_full_name                   | Full legal name |
| Tenant Email                  | tenant_email                       | Used for login/contact |
| Tenant Phone                  | tenant_phone                       | Mobile or home |
| Current Address               | tenant_current_address             | Optional for records |
| Property Address              | property_listing_address           | Full address |
| Unit Number                   | unit_number                        | Apt/Ste # |
| Property ID                   | property_id                        | Internal reference |
| Payment ID                    | payment_reference                  | Stripe/Connectlinx ID |
| Payment Type                  | payment_type                       | Deposit, Rent, Fee |
| Payment Amount                | payment_amount                     | USD |
| Lease Status                  | lease_status                       | Applied, Approved, Signed |
| Listing Source                | listing_source                     | TurboTenant, Zillow, etc. |
| Marketing Status              | marketing_status                   | Active, Paused |
| Onboard Status                | onboard_status                     | Pending, Verified, Published |

---

## Folder Structure

```plaintext
rental-turbotenant-internal-property/
│
├── /src
│   ├── api/
│   │   ├── turboTenantSync.js
│   │   ├── stripeHandler.js
│   │   └── hubspotIntegration.js
│   ├── models/
│   │   └── tenantMapping.json
│   └── index.js
│
├── /config
│   ├── env.example
│   ├── turboTenant.config.js
│   └── stripe.config.js
│
├── /docs
│   └── data-mapping.md
│
├── .gitignore
├── LICENSE
└── README.md
```

---

## Environment Variables (`.env` Template)

```bash
# TurboTenant Configuration
DOMAIN=turbotenant.com
WEB_URL=https://rental-turbotenant-147061670.hs-sites-eu1.com/home
SUB_DOMAIN=rental.turbotenant.com
DEFAULT_EMAIL_FORMAT={{firstName}}@turbotenant.com

# Support Contact
SUPPORT_EMAIL=support@147061670.eu1.r.hubspot-inbox.com

# Stripe Integration
STRIPE_SECRET_KEY=${{ secrets.STRIPE_SECRET_KEY }}
STRIPE_CLIENT_ID=${{ secrets.STRIPE_CLIENT_ID }}
STRIPE_WEBHOOK_SECRET=${{ secrets.STRIPE_WEBHOOK_SECRET }}

# HubSpot Integration
HUBSPOT_API_KEY=${{ secrets.HUBSPOT_API_KEY }}
GTM_CONTAINER_ID=${{ secrets.GTM_CONTAINER_ID }}
GA4_PROPERTY_ID=${{ secrets.GA4_PROPERTY_ID }}
```

---

## Deployment Instructions

1. **Clone Repository**
   ```bash
   git clone https://rental.turbotenant.com/auth/login/?internal/property/create/gtm-ndvjnct8-mze1m
   cd rental-turbotenant-internal-property
   ```

2. **Install Dependencies**
   ```bash
   npm install
   ```

3. **Configure Environment**
   - Copy `.env.example` → `.env`
   - Update all secret keys and email references  

4. **Run Development Server**
   ```bash
   npm run dev
   ```

5. **Deploy to Production**
   ```bash
   npm run build && npm run start
   ```

---

## Support

For technical support, onboarding assistance, or integration issues, contact our dedicated support team at:  
📧 **support@147061670.eu1.r.hubspot-inbox.com**

---

## Author

**TurboTenant Property Management Automation Team**  
Maintained under internal development and deployment guidelines for all property and tenant onboarding automation.
